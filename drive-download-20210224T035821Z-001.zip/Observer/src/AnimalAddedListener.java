
public interface AnimalAddedListener {
	
	public void update(Object newState);

}


public class Circle extends Shape{
	private int radius;
	public Circle(int xVal, int yVal, int r) {
		super(xVal, yVal);
		radius = r;
	}
	public Circle(Circle c) {
		super(c);
		if(c!= null) {
			radius = c.radius;
		}
	}
	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if(!super.equals(o)) {
			return false;
		}
		if(getClass() != o.getClass()) {
			return false;
		}
		Circle c = (Circle)o;
		return radius == c.radius;
	}
	@Override
	public Shape clone() {
		return new Circle(this);
	}

}

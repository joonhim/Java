
public class main {
	public static void main(String[] args) {
		Circle c1 = new Circle(1,2,3);
		Circle c2 = new Circle (4,5,6);
		
		Circle c1Copy = c1;// shallow copy
		
		Shape c2Copy = c2.clone();//deep copy
		
		if (c1== c1Copy) {
			System.out.println("C1 - Same mem addr");
		}else {
			System.out.println("C1 - Diff mem addr");
		}
		if (c2== c2Copy) {
			System.out.println("C2 - Same mem addr");
		}else {
			System.out.println("C2 - Diff mem addr");
		}
		
		if(c1.equals(c1Copy)) {
			System.out.println("C1 - Same Values");
		}else {
			System.out.println("C1 - Diff Values");
		}
		if(c2.equals(c1Copy)) {
			System.out.println("C2 - Same Values");
		}else {
			System.out.println("C2 - Diff Values");
		}
	}

}

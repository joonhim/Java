
public abstract class Shape {
	private int x, y;
	public Shape (int xVal, int yVal) {
		x = xVal;
		y = yVal;
	}

	public Shape (Shape s) {
	if (s != null) {
		x= s.x;
		y = s.y;
	}
}
	
	public abstract Shape clone();
	
	@Override
	public boolean equals(Object o) {
		if(this == o) {
			return true;
		}
		if(o == null) {
			return false;
		}
		if(getClass() != o.getClass()) {
			return false;
		}
		Shape s = (Shape)o;
		return x == s.x && y == s.y;
	}
}

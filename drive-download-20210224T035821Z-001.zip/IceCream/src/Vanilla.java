public class Vanilla extends IceCream {
 public static final double COST = 1.05;
 
 public Vanilla() {
  description = "Creamy Vanilla";
 }
 
 public double cost() {
  return COST;
 }

}

//public interface Entity{//Get functions for all
//  public String getDescription();
//  public double getmaxHp();
//  public double gethp();
//  public double getheal();
//  public double gettakeDamage(int x);
//}
public abstract class Entity {
  public String name;
  public double maxHp;
  public double hp;

  public Entity(String n, int mhp) {
    this.name = n;
    this.maxHp = mhp;
    this.hp = mhp;
  }

public abstract String attack(Entity e);

  public String getName() {
    return name;
  }

  public double getHp() {
    return hp;
  }

  public double getMaxHp() {
    return maxHp;
  }

  public void heal(int h) {
    hp += h;
    if (hp < maxHp) {
      hp = maxHp;
    }
  }

  public void takeDamage(int h) {
    hp -= h;
    if (hp < 1) {
      hp = 0;
    }
  }

  public String toString() {
    return name + "\nHP: " + hp + "/" + maxHp;
  }
}
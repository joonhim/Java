public abstract class EnemyDecorator extends Enemy{
  protected Enemy tempEntity;

  public EnemyDecorator(Entity newEntity){

    tempEntity = newEntity;
  }
  public String getDescription(){//Describing the enemy
    return tempEntity.getDescription();
  }

  public double gethp(){
    return tempEntity.gethp();
  }

  public double getheal(){ 		//Adds hp up to maximum of the max hp
 		double newHp = hp + h;
 		if (newHp < maxHp)
 		{
			hp = newHp;
		}
		else
		{
			hp = maxHp;
		}
    return tempEntity.getheal();
	}
  	
  public double gettakeDamage() {
		//Removes hp down to a minimum of 0
	  double newHp = hp - h;
		if (newHp < 0) {
			hp = 0;
		}
		else {
			hp = newHp;
		}
    return tempEntity.gettakeDamage(0);
	}
  
}
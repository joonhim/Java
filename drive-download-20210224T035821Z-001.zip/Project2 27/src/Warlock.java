public abstract class Warlock extends EnemyDecorator implements Magical{
  //setting Warlock
  public Warlock(Entity newEntity){
    super(newEntity);
    System.out.println("New Enemy Class Changed");//change to warlock

    System.out.println("Enemy Warlock" );
  }
   public String getDescription(){//Warlock description
    return tempEntity.getDescription() + ", Warlock";
  }

  public double gethp(){//Health
    return tempEntity.gethp() + 1;
  }
}
import java.util.Random;
import java.util.*;

public class EnemyGenerator {//Factory 
private static EnemyGenerator instance = null;
private ItemGenerator ig;
  public static EnemyGenerator getInsatnce(){
    if (instance == null){
      instance = new EnemyGenerator();
    }
    return instance;
  }
	public Enemy generateEnemy(int n, int lvl) {//lvl = level
    if (n == 0){
      Enemy x = new Orc();
      if (lvl > 1){
        int w = (int)(Math.random()*2);
        if(w == 0){//randomise to make warrior or warlock
          for(int i = 1; i < lvl; i++){
            new Warrior(x, "Warrior", 1);
          }
        }else{
          for(int i = 1; i<lvl; i++){
            new Warlock(x, "Warlock", 2);
          }
        }
      }return x;
    }
    else if (n == 1){
      Enemy x = new Froglok();
      if (lvl > 1){
        int w = (int)(Math.random()*2);
        if(w == 0){//randomise to make warrior or warlock
          for(int i = 1; i < lvl; i++){
            new Warrior(x, "Warrior", 1);
          }
        }else{
          for(int i = 1; i<lvl; i++){
            new Warlock(x, "Warlock", 2);
          }
        }
       }return x;
    }else if (n == 2){
      Enemy x = new Troll();
      if (lvl > 1){
        int w = (int)(Math.random()*2);
        if(w == 0){//randomise to make warrior or warlock
          for(int i = 1; i < lvl; i++){
            new Warrior(x, "Warrior", 1);
          }
        }else{
          for(int i = 1; i<lvl; i++){
            new Warlock(x, "Warlock", 2);
          }
        }
      }return x;
    }else if (n == 3){
      Enemy x = new Goblin();
      if (lvl > 1){
        int w = (int)(Math.random()*2);
        if(w == 0){//randomise to make warrior or warlock
          for(int i = 1; i < lvl; i++){
            new Warrior(x, "Warrior", 1);
          }
        }else{
          for(int i = 1; i<lvl; i++){
            new Warlock(x, "Warlock", 2);
          }
        }
      }return x;
    }
	}
}
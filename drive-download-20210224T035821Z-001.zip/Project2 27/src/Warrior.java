public abstract class Warrior extends EnemyDecorator{
  //Warrior setting
  public Warrior(Entity newEntity){
    super(newEntity);
    System.out.println("New Enemy Class Changed");//Change class to warrior

    System.out.println("Enemy Warrior" );
  }
   public String getDescription(){//set to warrior
    return tempEntity.getDescription() + ", Warrior";
  }

  public double gethp(){//Health
    return tempEntity.gethp() + 2;
  }
}
import java.util.Random;
import java.util.Scanner;

/*The main function
creates a hero and a map for each level the hero is on
for each location on the map, there will be a room.
there are 5 possible rooms
's' is the starting room and where the store is.
'n' means there is nothing, you may move on.
'm'means there is a monster in that room which you must either fight or run away from
'i' ther is an item in that room that the hero may pick up or leave alone
lastly 'f' is the finish, after reaching this room, you may go onto the next level if you have a key. keys may be found by killing a monster or purchasing through the store.
The game is overe once the hero dies (runs out of hp)*/
public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Map map = Map.getInsatnce();
    int mapLevel = 0;
    map.loadMap(mapLevel);

    System.out.println("What is your name, traveler?");
    String name = scanner.nextLine();
    Hero user = new Hero(name, map);

    map.reveal(user.getLocation());// Edge Case because first location won't be revealed otherwise

    while (true) {
      System.out.println(user);
      map.displayMap(user.getLocation());

      char room = ' ';

      System.out.println("1. Go North");
      System.out.println("2. Go South");
      System.out.println("3. Go East");
      System.out.println("4. Go West");
      System.out.println("5. Quit");
      int directionChoice;
      do {
        directionChoice = scanner.nextInt();
      } while (directionChoice < 1 || directionChoice > 5);

      Point p = user.getLocation();
      int x = p.getX();
      int y = p.getY();
      switch (directionChoice) {
      case 1:// North
        x--;
        break;
      case 2:// South
        x++;
        break;
      case 3:// East
        y++;
        break;
      case 4:// West
        y--;
        break;
      }
      while (x < 0 || y < 0 || x > 4 || y > 4) {
        System.out.println("Out of Bounds. Choose a new direction.");
        directionChoice = scanner.nextInt();
        p = user.getLocation();
        x = p.getX();
        y = p.getY();
        switch (directionChoice) {
        case 1:// North
          x--;
          break;
        case 2:// South
          x++;
          break;
        case 3:// East
          y++;
          break;
        case 4:// West
          y--;
          break;
        }
      }
      switch (directionChoice) {
      case 1:
        room = user.goNorth();
        break;
      case 2:
        room = user.goSouth();
        break;
      case 3:
        room = user.goEast();
        break;
      case 4:
        room = user.goWest();
        break;
      case 5:
        System.out.println("Game Over.");
        scanner.close();
        System.exit(0);
        break;
      }
      map.reveal(user.getLocation());
      EnemyGenerator enemyGenerator = new EnemyGenerator(itemGenerator);
      Point start = new Point(map.findStart().getX(), map.findStart().getY());
      switch (room) {
      case 'm':
        if (!monsterRoom(user, map, enemyGenerator, mapLevel)) {
          System.out.println("Game Over.");
          scanner.close();
          System.exit(0);
        }
        break;
      case 'n':
        System.out.println("There was nothing here.");
        break;
      case 'i':
        itemRoom(user, map, itemGenerator);
        break;
      case 's':
        store(h);
        break;
      case 'f':
        System.out.println("You've reached the finish.");
        mapLevel++;
        mapLevel %= 3;
        map.loadMap(mapLevel);
        user.heal(25);// = new Hero(name, map);//Bug: Inventory is getting reset
        start = new Point(map.findStart().getX(), map.findStart().getY());
        map.reveal(start);
        break;
      }
      if (!map.findStart().equals(start)) {
        mapLevel++;
      }
    }
  }

  /*fight the monster or run away
  @param hero, access to hp and inventory
  @param map, location of the room
  @param itemgenerator, the monster will have a random item drop
  @param maplevel, the higher the level, the more hp the monster will have
  you will have to either fight the monster until it dies or if you decide to run away
  if you run away, you run into a random direction, into the next room
  @returns true if you run or defeat the monster
  @returns false if you died*/
  public static boolean monsterRoom(Hero h, Map m, EnemyGenerator eg, int mapLevel) {
    // Return True if Enemy Dies or no one dies, False if Hero Dies
    boolean fightOver = false;
    System.out.println("You've encountered a " + enemy.getName());
    Scanner scanner = new Scanner(System.in);

    while (!fightOver) {
      System.out.println(enemy);
      System.out.println("1. Fight");
      System.out.println("2. Run Away");
      if (h.hasPotion()) {
        System.out.println("3. Drink Health Potion");
      }
      int choice;
      if (h.hasPotion()) {
        do {
          choice = scanner.nextInt();
        } while (choice < 1 || choice > 3);
      } else {
        do {
          choice = scanner.nextInt();
        } while (choice < 1 || choice > 2);
      }
      int randNum = 0;
      switch (choice) {
      case 1:
        if (!fight(h, enemy)) {
          fightOver = true;
        }
        break;
      case 2:
        Random rand = new Random();
        char room = ' ';

        Point p;
        int x, y;
        do {
          p = h.getLocation();
          x = p.getX();
          y = p.getY();
          randNum = rand.nextInt(4);// 4 directions, maybe static var
          switch (randNum) {
          case 0:// North
            x--;
            break;
          case 1:// South
            y++;
            break;
          case 2:// East
            x++;
            break;
          case 3:// West
            y--;
            break;
          }
        } while (x < 0 || y < 0 || x > 4 || y > 4);
        switch (randNum) {
        case 0:
          room = h.goNorth();
          break;
        case 1:
          room = h.goEast();
          break;
        case 2:
          room = h.goSouth();
          break;
        case 3:
          room = h.goWest();
          break;
        }
        m.reveal(h.getLocation());
        EnemyGenerator enemyGenerator = new EnemyGenerator(itemGenerator);
        switch (room) {
        case 'm':
          if (!monsterRoom(h, m, enemyGenerator, mapLevel)) {
            System.out.println("Game Over.");
            scanner.close();
            System.exit(0);
          }
          break;
        case 'n':
          System.out.println("There was nothing here.");
          break;
        case 'i':
          itemRoom(h, m, itemGenerator);
          break;
        case 's':
          System.out.println("You're back at the start.");
          break;
        case 'f':
          System.out.println("You've reached the finish.");
          if (h.hasKey() == true) {
            h.useKey();
            mapLevel++;
            mapLevel %= 3;
            m.loadMap(mapLevel);
            h.heal(25);
            m.reveal(h.getLocation());
            break;
          }
          else {
            System.out.println("You need a Key to move on to the next leve. Come back after you have obtained a Key.");
            break;
          }
        }
        fightOver = true;
        break;
      case 3:
        h.drinkPotion();
        System.out.println(h);
        break;
      }
    }
    if (h.getHP() == 0) {
      System.out.println("You have died.");
      return false;
    }
    if (enemy.getHP() == 0) {
      System.out.println("You defeated the " + enemy.getName() + "!");
      if (h.pickUpItem(enemy.getItem())) {
        System.out.println("You received a " + enemy.getItem().getName() + " from its corpse.");
      }
      m.removeCharAtLoc(h.getLocation());
      return true;
    }
    return true;
  }

  /*fight the monster
  updates the health of the enemy and hero
  @returns false if the fight is over, if either enemy or hero Dies
  @returns true if bother entities are still alive*/
  public static boolean fight(Hero h, Enemy e) {
    // If Hero or Enemy dies, return false
    System.out.println(h.attack(e));
    if (e.getHP() == 0) {
      return false;
    }
    System.out.println(e.attack(h));// Need to define
    if (h.getHP() == 0) {
      return false;
    }
    return true;
  }

  /*item room
  @param hero, access to Inventory
  @param map, location on the map
  @param itemgenerator to make a random item
  the room will have no monster, just a random item.
  hero can choose to pick up the item in the room or leave it*/
  public static void itemRoom(Hero h, Map m, ItemGenerator ig) {
    Item item = ig.generateItem();
    System.out.println("You found a " + item.getName());
    if (h.pickUpItem(item)) {
      System.out.println("You received a " + item.getName());
      m.removeCharAtLoc(h.getLocation());
    }
  }
  /*store
  @param Hero, uses the hero's Inventory
  asks if the hero would like to buy, sell, or leave
  if they choose to buy, they may either purchase healthpotions or keys. item will be added to hero's inventory after purchase.
  if they sell, the store will look into their inventory for the player to select something they would like to sell. The item will be deleted from the hero's inventory after transaction.
  if they chose to leave, the transaction is over*/
  public static void store(Hero h) {
    boolean store = true;
    System.out.println("Welcome to the store. \nWould you like to buy, sell, or leave? b/s/l");
    while (store == true) {
      char choice = scanner.nextLine();
      if (choice == 'b') {
        boolean buy = true;
        while (buy == true) {
          boolean x = true;
          System.out.println("Please select an item to buy. \nStore Inventory: \n1. Health Potion \t\t25 \n2. Key \t\t50 \n(Select Number of Item)");
          int item = scanner.nextInt();
          if (item == 1) {
            while (x == true) {
              System.out.println("Would you like to buy a Health Potion for 25 gold? y/n");
              char y = scanner.nextLine();
              if (y == 'y') {
                Item i = itemGenerator.get(0);
                int g = Integer.parseInt(s[1]);
                h.spendGold(25);
                if (h.pickUpItem(i)) {
                  System.out.println("You bought a " + i.getName() + " from the store.");
                }
                x = false;
                buy = false;
              }
              else if (y == 'n') {
                x = false;
                buy = false;
              }
            }
          }
          else if (item == 2) {
            while (x == true) {
              System.out.println("Would you like to buy a Key for 50 gold? y/n");
              char y = scanner.nextLine();
              if (y == 'y') {
                Item i = itemGenerator.get(1);
                h.spendGold(50);
                if (h.pickUpItem(i)) {
                  System.out.println("You bought a " + i.getName() + " from the store.");
                }
                x = false;
                buy = false;
              }
              else if (y == 'n') {
                x = false;
                buy = false;
              }
            }
          }
        }
      }
      else if (choice == 's') {
        boolean sell = true;
        while (sell == true) {
          System.out.println("Select something to sell.\n" + h.itemsToString() + "\n(Select Number of Item)");
          int item = scanner.nextLine();
          if (item < h.getNumItems() && item > 0) {
            System.out.println("Do you wish to sell your " + h.getItemName(item) + "? (y/n)");
            char y = scanner.nextLine();
            if (y == 'y') {
              Item x = h.dropItem(item);
              h.collectGold(x.getValue());
              System.out.println("You recieved " + x.getValue() + " gold for your " + x.getName());
              sell = false;
            }
            else if (y == 'n') {
              sell = false;
            }
          }
        }
      }
      else if (choice == 'l') {
        store = false;
      }
      else {
        System.out.println("Would you like to buy, sell, or leave? b/s/l");
      }
    }
  }
}
public abstract class Goblin extends Enemy{
  //Monster Name and HP and Item carrying
  public Goblin(){
    name = "Goblin";
    maxHp=2.0;
    hp = 2.0;
    ItemGenerator ig = ItemGenerator.getInstance();
    ig = ig.generateItem();
  }
//Attacks and damage takes
  public String attack(Hero h){
    int damage = (int)(Math.random()*4)+1;
    if (h.hasArmor() > -1) { 
      damage = 0;//initialize damage
      h.dropItem(h.hasArmor());
    }
    h.takeDamage(damage);//hero damage enemy
    String s = "HP lowered " + damage + "damage: ";
    System.out.println(s);
    return s;
  }
}
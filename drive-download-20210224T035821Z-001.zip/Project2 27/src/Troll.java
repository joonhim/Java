public abstract class Troll extends Enemy{
 //Enemy Name and hp and item
  public Troll(){
    name = "Troll";
    maxHp=5.0;
    hp = 5.0;
    ItemGenerator ig = ItemGenerator.getInstance();
    ig = ig.generateItem();
  }
//Attacks and damage takes
  public String attack(Hero h){
    int damage = (int)(Math.random()*4)+1;
    h.takeDamage(damage);//Hero give damage
    if (h.hasArmor() > -1) { 
      damage = 0;//initialize damage
      h.dropItem(h.hasArmor());
    }
    String s = "HP lowered " + damage + "damage: ";
    System.out.println(s);
    return s;
  }
}
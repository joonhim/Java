import java.util.ArrayList; 
import java.util.Random;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class ItemGenerator {
  private static ItemGenerator instance = null;
	private ArrayList<Item> itemList;

	//Constructor
  /*reads from a file
  for each line in the file, creates a new String
  split each string by the ","
  each split is made into one parameter of class Item
  each item is added to itemList*/
	private ItemGenerator() {
		Scanner read = null;
		itemList = new ArrayList<Item>();
	  try {
			read = new Scanner(new File("itemList.txt"));
			while(read.hasNext()) {
        String[] s = read.nextLine().split(",");
        String name = s[0];
        int value = Integer.parseInt(s[1]);
        char type = s[2];
        Item i = new Item(name, value, type);
        itemList.add(i);
			}
			read.close();
	  } catch(FileNotFoundException e) {
	    System.out.println("File Not Found - place file in the project folder. ");
	  }
	}

  //DP Singleton 
  public static ItemGenerator getInstance(){
    if (instance == null){
      instance = new ItemGenerator();
    }
    return instance;
  }

  /*looks through itemList to give back a random Item in the ArrayList
  @return clone of random Item*/
	public ItemGenerator generateItem() {
		//Return a random Item
		Random rand = new Random(); 
    Item item = itemList.get(rand.nextInt(itemList.size()));
    return item.clone();
	}
}
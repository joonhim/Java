public abstract class Orc extends Enemy{
  //Name of Enemy and HP
  public Orc(){
    name = "Orc";
    maxHp=4.0;
    hp = 4.0;
    ItemGenerator ig = ItemGenerator.getInstance();
    ig = ig.generateItem();
  }
//Attacks and damage takes
  public String attack(Hero h){
    int damage = (int)(Math.random()*4)+1;
    if (h.hasArmor() > -1) { 
      damage = 0;
      h.dropItem(h.hasArmor());
    }
    h.takeDamage(damage);
    String s = "HP lowered " + damage + "damage: ";
    System.out.println(s);
    return s;
  }
}
import java.util.Random;

public abstract class Enemy extends Entity{
  private Item item;
@Override
  /*
  *Constructor - Create an Enemy Object
  @param n the name of enemy
  @param mHp the maximum health points
  @param i the item the enemy has
  */
  public Enemy(String n, int mHp, Item i ) {
    super(n, mHp);
    this.item = i;
  }

  /*attacks the Hero
  @param hero
  does a random amount of damage based on the monsters hp
  if the hero has armor, the monster does 0 damage and the armor is dropped
  @returns string summarizing the event*/
  @Override
  public String attack(Entity E) {
    Random rand = new Random();
    //generates an atk dmg that is somewhere between the range of their own hp
    int atk = rand.nextInt(this.getHp()) + 1;
    E.takeDamage(atk);
    String s = this.getName() + " attacked " + E.getName() + " for " + atk + " damage.";
    return s;
  }

  /*gets the item carried by tthe entity
  @return item*/
  public Item getItem(){
    return this.item;
  }
}
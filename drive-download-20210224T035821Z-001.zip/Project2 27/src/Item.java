public class Item  {	  
	public String name;
  public int value;
  public char type;

  /*constructor for item
  @param string for name
  @param int for the value
  @param char for the type of item*/
	public Item(String n, int v, char t) {
		name = n;
    value = v;
    type = t;
	}
	/*gets the item's name
  @return string of the item name*/
	public String getName() {
	  return name;
	}
  /*gets the item's gold value
  @return int for value*/
  public int getValue() {
    return value;
  }
  /*gets the item's type
  @return char of the type of item*/
  public char getType() {
    return type;
  }
	/*sets the name of the item
  @param name to be set as the item name*/
	public void setName(String name) {
	  this.name = name;
	}

  //prototype
  public Item(Item i) {
    if(ig != null ) {
      this.name = i.name;
      this.value = i.value;
      this.type = i.type;
    }
  }
  @Override public Item clone( ) {
    return new Item( this );
  }
} 
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList;

public class Hero extends Entity implements Magical {
	private ArrayList<Item> items;
	private Map map;
	private Point location;
  private int gold;

  /*Constructor
  @param name of hero
  @param map, location of hero
  creates a new hero with a name, mHP, an inventory, gold, and a location*/
	public Hero(String n, Map m) {
		super(n, 25);
		map = m;
		items = new ArrayList<Item>();
    gold = 0;
		location = new Point(map.findStart().getX(), map.findStart().getY());
	}
  /*prints out the hero's inventory
  runs in a loop to print each item*/
	public String itemsToString() {
		String itemString = "";
		Item item;
		itemString += "Inventory:";
		for(int i = 0; i < getNumItems(); i++) {
			item = items.get(i);
			itemString += "\n";
			itemString += (i+1) + ". " + item.getName();
		}
		return itemString;
	}
  /*gets the number of items in inventory
  @return size of ArrayList items*/
	public int getNumItems() {
		return items.size();
	}
  /*picks up an item and places it in the inventory
  @param item to add
  asks user if they would like to pick up item
  if yes, they will pick up the item
  if the hero's inventory is full, they can choose to swap the item out
  @return boolean if they pick up item, return true, otherwise return false*/
	public boolean pickUpItem(Item i) {
		if (getNumItems() < 5) {
			items.add(i);
			return true;
		}
		Scanner scanner = new Scanner(System.in);
		System.out.println("Your inventory is too full for a " + i.getName() + ".");
		System.out.println("1. Leave " + i.getName());
		System.out.println("2. Replace an item in your inventory with " + i.getName());
		int inventoryChoice;
		do {
			inventoryChoice = scanner.nextInt();
		}
		while(inventoryChoice < 1 || inventoryChoice > 2);
		if (inventoryChoice == 2) {
			System.out.println("Choose the item to replace");
			for (int index = 1; index <= 5; index++) {
				System.out.println(index + ". " + items.get(index-1).getName());
			}
			int itemToReplace = scanner.nextInt();
			System.out.println(items.get(itemToReplace-1).getName() + "replaced with " + i.getName());
			items.set(itemToReplace-1, i);
			return true;
		}
		return false;
	}
  /*the hero will drink a potion to regain up to 25 hp
  the hero's added hp cannot go over his maxHP
  the health potion will be dropped out of the inventory after its use*/
	public void drinkPotion() {
		if (hasPotion()) {
			//Increase 25 HP
			heal(25);
			/*
			if (hp + 25 > maxHp)
			{
				hp = maxHp;
			}
			else
			{
				hp += 25;
			}
			*/
		}
		//Take Health Potion out of inventory
		boolean dropped = false;
		for (int i = 0; i < getNumItems(); i++)
		{
			if (items.get(i).getName().equals("Health Potion") && !dropped)
			{
				dropItem(i);
				dropped = true;
			}
		}
	}
  /*deletes item from ArrayList items
  @param index of items you would like to remove
  creates a temp of what you want to delete
  @returns the temp*/
	public Item dropItem(int index) {
    Item temp = items(index-1);
		items.remove(index-1);
    return temp;
	}
  /*checks the hero inventory to see if they have a health potion
  @return returns true if they have a potion, otherwise returns false*/
	public boolean hasPotion() {
		for (Item item: items) {
			if (item.getName().equals("Health Potion")) {
				return true;
			}
		}
		return false;
	}
  /*gets the amount of gold the hero has
  @return the int of the gold amount hero has*/
  public int getGold() {
    return gold;
  }
  /*adds an amount of gold into the hero's popckets
  @param the int amoung of the gold to be added
  no limit to gold amount*/
  public void collectGold(int g) {
    gold += g;
    System.out.println("You recieved " + g + "gold. You now have " + gold + "gold.");
  }
  /*minuses an amount of gold from the hero's popckets
  @param int amount of gold to spend
  if the amount you want to spend is over the hero's budget, you will not spend the gold*/
  public void spendGold(int g) {
    gold -= g;
    if (gold < 0) {
      gold += g;
      System.out.println("Not enough gold.");
    }
    else {
      System.out.println("You spent " + g + "gold. You now have  " + gold + "gold.");
    }
  }
  /*checks the hero's inventory if they have a key item
  @return true if there is a key type item, otherwise returns false*/
  public boolean hasKey() {
    for (int i = 0; i < items.size(); i++) {
      if(items.get(i).getType() == 'k') {
        return true;
      }
    }
    return false;
  }
  /*if there is a key in the hero's inventory, they will drop the key from the inventory*/
  public void useKey() {
    if (hasKey() == true) {
      boolean dropped = false;
		  for (int i = 0; i < getNumItems(); i++) {
			  if (items.get(i).getName().equals("Key") && !dropped) {
				  dropItem(i);
				  dropped = true;
			  }
		  }
    }
  }
  /*searches the inventory for any armor type items
  @return the int index of the armor type in the items ArrayList
  if there is no armor type, @returns -1*/
  public int hasArmor() {
    for (int i = 0; i < items.size(); i++) {
      if(items.get(i).getType() == 'a') {
        return i;
      }
    }
    return -1;
  }
  /*getName of the item at index
  @return item string name*/
  public String getItemName(int x) {
    return h.items(x-1).getName();
  }
  /*get location of hero
  @return map location*/
	public Point getLocation() {
		return location;
	}
  //hero goes east position
  //@return char at map location
	public char goEast() {
		location.translate(0, 1);
		return map.getCharAtLoc(location);
	}
  //hero goes west position
  //@return char at map location
	public char goWest() {
		location.translate(0, -1);
		return map.getCharAtLoc(location);
	}
  //hero goes south position
  //@return char at map location
	public char goSouth() {
		location.translate(1, 0);
		return map.getCharAtLoc(location);
	}
  //hero goes north position
  //@return char at map location
	public char goNorth() {
		location.translate(-1, 0);
		return map.getCharAtLoc(location);
	}
  /*prints out all the stats of the hero
  @return string of the current development of the hero*/
	public String toString() {
		String str = super.toString() + "\n";
    str += "\nGold: " + gold;
		str += itemsToString();
		return str;
	}
  /*hero attacks a monster
  @param monster getting attacked
  hero gets to choose to do either a physical or magical attack
  magic attacks are implemented from magical interface
  both attacks do a random amount of damage
  the random amount of damage is subtracted from the monster's hp
  @return a string summarizing what happened*/
	public String attack(Entity e) {
		Random rand = new Random();
		Scanner scanner = new Scanner(System.in);
		System.out.println("1. Physical Attack");
		System.out.println("2. Magic Attack");
		int attackChoice;
		do {
			attackChoice = scanner.nextInt();
		}
    while(attackChoice < 1 || attackChoice > 2);
		String str = "";
		switch(attackChoice) {
			case 1:
				int maxDamage = e.getMaxHp() * 2;
				int randomDamage = rand.nextInt(maxDamage);
				randomDamage++;
				e.takeDamage(randomDamage);
				str += name + " attacks " + e.getName() + " for " + randomDamage + " damage.";
				break;
			case 2:
				System.out.println(Magical.MAGIC_MENU);
				int magicAttackChoice;//Needs Validation
				do{
					magicAttackChoice = scanner.nextInt();
				}while(magicAttackChoice < 1 || magicAttackChoice > 3);
				switch(magicAttackChoice) {
					case 1:
						str += magicMissile(e);
						break;
					case 2:
						str += fireball(e);
						break;
					case 3:
						str += thunderclap(e);
						break;
				}
			break;
		}
		//scanner.close();
		return str;
	}
  /*one of the magic attacks the hero can choose to do
  @param monster the hero is attacking
  @returns string summarizing the attack*/
	public String magicMissile(Entity e) {
		String str = "";
		int maxDamage = e.getMaxHp() * 2;
		Random rand = new Random();
		int damageToTake = rand.nextInt(maxDamage);
		damageToTake++;
		e.takeDamage(damageToTake);
		str += name + " hits " + e.getName() + " with a Magic Missile for " + damageToTake + " damage.";
		return str;
	}
  /*one of the magic attacks the hero can choose to do
  @param monster the hero is attacking
  @returns string summarizing the attack*/
  public String fireball(Entity e) {
		String str = "";
    int maxDamage = e.getMaxHp() * 2;
    Random rand = new Random();
    int damageToTake = rand.nextInt(maxDamage);
    damageToTake++;
    e.takeDamage(damageToTake);
    str += name + " hits " + e.getName() + " with a Fireball for " + damageToTake + " damage.";
    return str;
  }
  /*one of the magic attacks the hero can choose to do
  @param monster the hero is attacking
  @returns string summarizing the attack*/
  public String thunderclap(Entity e) {
		String str = "";
    int maxDamage = e.getMaxHp() * 2;
    Random rand = new Random();
    int damageToTake = rand.nextInt(maxDamage);
    damageToTake++;
    e.takeDamage(damageToTake);
    str += name + " zaps " + e.getName() + " with a Thunderclap for " + damageToTake + " damage.";
    return str;
  }
}
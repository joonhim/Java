
public class MountainBike extends Bicyle {
	private Bicyle b;
	
	public SeatHeight(int H){
		setSeatHeight(H);
	}

}

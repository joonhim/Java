package emailapp;

public class emailapp {

	public static void main(String[] args) {
		Email em1 = new Email("Joon", "Im");
		em1.showInfo();
		System.out.println(em1.showInfo());
	}

}


public interface CatState {
	public void sleep(Cat c);
	public void eat(Cat c);
	public void play(Cat c);
	public void ignore(Cat c);
	

}


public class main {
	public static void main(String[] args) {
		Factory f = new ShapeFactory();
		f.drawShape("Circle");
		f.drawShape("Square");
}
}

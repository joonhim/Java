
public class Tests {
public static void main(String args[]) {
	MilesClient MC = new MilesClient();
	
	System.out.println(MC.distance(90, 6));
}
}

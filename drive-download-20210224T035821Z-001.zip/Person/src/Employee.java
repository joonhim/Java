
public class Employee extends Person{
	public Employee(String name, String address) {
		super(name, address);
		// TODO Auto-generated constructor stub
	}

	private String jobDesc;
	private double salary;
	
	public void Emplyee(String name, String address, String desc, double sal) {
		super(name, address);
		jobDesc = desc;
		salary = sal;
		
	}
	
	public void doJob() {
		return "WORKING...";
		
	}
	public void display() {
		super.display();
		System.out.println("Desc: " + jobDesc);
		System.out.println("Salary: " + salary);
	}
	
	@Override
	public String toString(){
		String s = super.toString();
		s+= "\nDesc: " + jobDesc;
		s+= "\nSalary: " + salary;
		
		return s;
	}
	
}


public class Person {
	private String name;
	private String addr;
	
	public Person(String name, String address)
	{
		this.name = name;
		addr = address;
	}

	public String getName() {
		return name;
	}
	public String getAddress() {
		return addr;
	}
	
	public void display() {
		System.out.println("Name: "+ name);
		System.out.println("Addr: "+ addr);
	}
	@Override
	public String toString() {
		String s = "Name: "+ name;
		s += "\nAddr: "+ addr;
		return s;
	}
}

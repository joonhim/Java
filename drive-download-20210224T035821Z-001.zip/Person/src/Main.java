
public class Main {
	public static void main(String[] args) {
		Person p1 = new Person("Greg", "123 Fake St.");
		Person p2 = new Person("Mary", "456 Main St.");
		
		System.out.println(p1);
		System.out.println(p2);
		
		System.out.println(p1.getName() + " " + p1.getAddress());
		
		Employee e1 = new Employee("Bob", "987 Elm Ln.", "Desktop Support", 60000);
		Employee e2 = new Employee("Ada", "876 Oak Way", "Manager", 90000);
		
		System.out.println(e1);
		System.out.println(e2);
		
		System.out.println(e1.doJob());
		
		e2.display();
		
		System.out.println(e1.getName()+ " " + e1.getAddr());
		
		Person e3 = new Employee ("ABC", "123 fkldsf", "desc", 12345);
		
		//e3.doJob();
		
		System.out.println(e3);
	}

}

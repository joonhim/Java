
public interface pizza {
	public double cost();

}


public class pizzaSmall implements pizza {
	@Override 
	public double cost() {
		System.out.println("Small Pizza... $5.00");
		return 5.0;
	}
}

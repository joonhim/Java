
public class pizzaLarge implements pizza {
	@Override 
	public double cost() {
		System.out.println("Large Pizza... $7.00");
		return 7.0;
	}
}


public class Main {
	public static void main(String[] args) {
	Mug m = new Mug();
	//Coffee c = new Coffee();
	//m.addLiquid(c);
	//Tea t = new Tea();
	
	//m.addLiquid(t);
	//Milk k = new Milk();
	//m.addLiquid(k);
	Whiskey w = new Whiskey();
	m.addLiquid(w);
	
	
	}
}

public class Milk extends Liquid {
	@Override
public void stir() {
	System.out.println("Stirring Milk");
	
}
}

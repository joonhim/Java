
public class Tea extends Liquid{
	@Override
	public void stir() {
		System.out.println("Stirring Tea");
	}
		
}

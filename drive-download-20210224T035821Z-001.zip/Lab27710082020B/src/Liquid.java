public abstract class Liquid {
	public abstract void stir();
	
	


}

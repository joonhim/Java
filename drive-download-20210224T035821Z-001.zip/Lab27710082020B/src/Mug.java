public class Mug {
	private Liquid liquid;
	
	
	public void addLiquid(Liquid l ) {
		liquid = l;
		liquid.stir();
		
		
	}

}

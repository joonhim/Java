public class Whiskey extends Liquid {
	@Override
public void stir() {
	System.out.println("Stirring Whiskey");
	
}
}


public class Coffee extends Liquid {
	@Override
public void stir() {
	System.out.println("Stirring Coffee");
	
}
}

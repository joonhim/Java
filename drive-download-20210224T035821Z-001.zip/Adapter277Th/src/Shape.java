
public class Shape {

	public void draw() {
		
	}

}

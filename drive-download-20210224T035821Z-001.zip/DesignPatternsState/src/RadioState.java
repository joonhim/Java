
public interface RadioState {
	public void turnOn( Radio r);
	public void turnOff( Radio r);
	public void changeStation( Radio r);

}


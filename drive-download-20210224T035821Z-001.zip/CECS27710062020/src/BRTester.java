import java.awt.Rectangle;
public class BRTester {
	public static void main(String [] args) {
		
			/*Rectangle r = new Rectangle(1,2,3,4);
			r.getArea();
			r.getPerimeter();*/
		
		
			/*Rectangle s = new BetterRectangle(1,2,3,4);
			s.getArea();
			s.getPerimeter();*/
		
		
			BetterRectangle t = new BetterRectangle(1,2,3,4);
			t.getArea();
			t.getPerimeter();
		
		
			/*BetterRectangle u = new Rectangle(1,2,3,4);
			u.getArea();
			u.getPerimeter();*/
		
		}
	}

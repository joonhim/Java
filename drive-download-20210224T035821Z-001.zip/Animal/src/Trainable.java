
public interface Trainable {
	public void speak();
	public void sit();
	public void fetch();
	public void laydown();

}

// Because we extend IceCream, IceCreamDecorator is-a IceCream

public abstract class IceCreamDecorator extends Dessert {
 public abstract String getDescription();
}

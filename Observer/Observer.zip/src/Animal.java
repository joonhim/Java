
public class Animal {
	private String name;

	public Animal(String name) {
		// TODO Auto-generated constructor stub
		this.name = name;
	}
	
	public String toString() {
		return "Animal:" + name;
	}

}
